import Layout from "@/components/Layout/Layout";
import Search from "@/components/Search";
import React from "react";

const search = () => {
  return (
    <Layout>
      <Search />
    </Layout>
  );
};

export default search;
