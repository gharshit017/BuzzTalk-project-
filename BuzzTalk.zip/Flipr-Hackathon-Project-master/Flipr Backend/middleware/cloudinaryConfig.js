const cloudinary = require('cloudinary').v2;

cloudinary.config({
    cloud_name: "ompra",
    api_key: "316452442986623",
    api_secret: "ol61Fq9h1aHG7C0eKUsUPeP-Kwk"
  });
